export interface Classroom {
  id?: number;
  nameClass?: string;
}
